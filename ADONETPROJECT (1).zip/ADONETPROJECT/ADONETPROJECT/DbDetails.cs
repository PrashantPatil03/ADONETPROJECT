﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ADONETPROJECT.MODEL;

namespace ADONETPROJECT
{
    public partial class DbDetails : Form
    {
        StudentLogic ob = new StudentLogic();
        public DbDetails()
        {
            InitializeComponent();
        }

        private void DbDetails_Load(object sender, EventArgs e)
        {
           
            CdTable.DataSource = ob.GetTabledata().Tables[0];
            CdTable.DisplayMember = "name";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int i = CdTable.SelectedIndex;
            i++;
            dataGridView1.DataSource = ob.GetTabledata().Tables[i];
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 ob = new Form1();
            ob.Show();
        }
    }
}
