﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace ADONETPROJECT.MODEL
{
    class StudentLogic
    {
        private string connStr = ConfigurationManager.ConnectionStrings["studb"].ConnectionString;

        public List<Student> getStudentDetails()
        {
            List<Student> li = new List<Student>();
            SqlConnection conn = new SqlConnection(connStr);
            try
            {
                conn.Open();
                string sql = "select *from Student";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Student s = new Student();
                    s.Id = Convert.ToInt32(reader.GetValue(0));
                    s.Name = reader.GetValue(1).ToString();
                    s.Email = reader.GetValue(2).ToString();
                    s.Phone = reader.GetValue(3).ToString();
                    s.Fees = float.Parse(reader.GetValue(4).ToString());
                    s.Percent = float.Parse(reader.GetValue(5).ToString());
                    li.Add(s);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
          return li;
        }
        public string AddData(Student student)
        {
            string message = " ";
            string sql = "insert into Student(STUDENTNAME,EMAIL,PHONE,FEES,\"PERCENT\") values('";
            sql += student.Name + "','" + student.Email + "','" + student.Phone + "'," + student.Fees + "," + student.Percent + ")";
            // string sql=String.Format("insert into Student(STUDENTNAME,EMAIL,PHONE,FEES,\"PERCENT\") values('{0}','{1}','{2}',{3},{4}")
            //    ,student.Name,student.Email,
            // MessageBox.Show(sql);
            SqlConnection conn = new SqlConnection(connStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                message = "the record inserted successfully:" + student.ToString();
            }
            catch (Exception e)
            {
                message = e.Message;
            }
            finally
            {
                conn.Close();
            }
            return message;
        }
        public DataSet GetSearchData(int id)
        {
            DataSet ds = new DataSet();
            SqlConnection conn = new SqlConnection(connStr);
            string sql = "select * from STUDENT where Id=" + id.ToString();
            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                da.Fill(ds);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }
        public DataSet GetTabledata()
        {
            DataSet ds = new DataSet();
            SqlConnection conn = new SqlConnection(connStr);
            string sql = "select * from sys.tables;select * from Student;select * from Staff";
            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(sql, conn);
                da.Fill(ds);
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }
        public string UpdateData(Student s)
        {
            string message = " ";
            SqlConnection conn = new SqlConnection(connStr);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("sproc_update",conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@id", SqlDbType.Int).Value = s.Id;
                cmd.Parameters.Add("@name", SqlDbType.VarChar,50).Value = s.Name;
                cmd.Parameters.Add("@email", SqlDbType.VarChar,50).Value = s.Email;
                cmd.Parameters.Add("@phone", SqlDbType.VarChar,10).Value = s.Phone;
                cmd.Parameters.Add("@fees", SqlDbType.Float).Value = s.Fees;
                cmd.Parameters.Add("@percent", SqlDbType.Float).Value = s.Percent;
                cmd.ExecuteNonQuery();
                message = "Data updated Successfully";
            }
            catch (Exception e)
            {
                message = e.Message;
            }
            finally
            {
                conn.Close();
            }
            return message;
        }
        public string DeleteData(int id)
        {
            string message = " ";
            SqlConnection conn = new SqlConnection(connStr);
            try
            {
               
              
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("Sproc_delete", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@id", SqlDbType.Int).Value = id;
                cmd.ExecuteNonQuery();
                message = "Data Deleted Successfully";

            }
            catch (Exception e)
            {
                message = e.Message;
            }
            finally
            {
                conn.Close();
            }
            return message;
        }
        public List<Student> getStudentPercent(float percent)
        {
            List<Student> li = new List<Student>();
            SqlConnection conn = new SqlConnection(connStr);
            try
            {
                conn.Open();
                string sql = "select *from Student where \"Percent\" > "+percent.ToString();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Student s = new Student();
                    s.Id = Convert.ToInt32(reader.GetValue(0));
                    s.Name = reader.GetValue(1).ToString();
                    s.Email = reader.GetValue(2).ToString();
                    s.Phone = reader.GetValue(3).ToString();
                    s.Fees = float.Parse(reader.GetValue(4).ToString());
                    s.Percent = float.Parse(reader.GetValue(5).ToString());
                    li.Add(s);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return li;
        }
    }
}
