﻿using ADONETPROJECT.MODEL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADONETPROJECT
{
    public partial class InsertData : Form
    {
        public InsertData()
        {
            InitializeComponent();
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            Student student = new Student();
            student.Name = txtname.Text;
            student.Email = txtemail.Text;
            student.Phone = txtphone.Text;
            student.Fees=float.Parse(txtfee.Text);
            student.Percent = float.Parse(txtpercent.Text);

            // MessageBox.Show(student.ToString());
            StudentLogic ob = new StudentLogic();
            string message = ob.AddData(student);
            MessageBox.Show(message);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 ob = new Form1();
            ob.Show();
        }

        private void InsertData_Load(object sender, EventArgs e)
        {

        }
    }
}
