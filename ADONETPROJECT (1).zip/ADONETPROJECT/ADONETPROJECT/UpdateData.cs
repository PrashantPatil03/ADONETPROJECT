﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ADONETPROJECT.MODEL;

namespace ADONETPROJECT
{
    
    public partial class UpdateData : Form
    {
        StudentLogic ob = new StudentLogic();
        public UpdateData()
        {
            InitializeComponent();
        }

        private void UpdateData_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            panel1.Visible = false;
            btnupdate.Visible = false;
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Form1 ob1 = new Form1();
            ob1.Show();
            this.Hide();
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtId.Value.ToString());
            DataSet res = ob.GetSearchData(id);
            if (Convert.ToInt32(res.Tables[0].Rows.Count.ToString()) > 0)
            {
                panel1.Visible = true;
                txtname.Text = res.Tables[0].Rows[0]["studentname"].ToString();
                txtemail.Text = res.Tables[0].Rows[0]["email"].ToString();
                txtphone.Text= res.Tables[0].Rows[0]["phone"].ToString();
                txtfees.Text=res.Tables[0].Rows[0]["fees"].ToString();
                txtpercent.Text= res.Tables[0].Rows[0]["percent"].ToString();
                btnupdate.Visible = true;

                /* Student stu = new Student();
                 stu.Id = id;
                 stu.Name = res.Tables[0].Rows[0]["studentname"].ToString();
                 stu.Email = res.Tables[0].Rows[0]["email"].ToString();
                 stu.Phone = res.Tables[0].Rows[0]["phone"].ToString();
                 stu.Fees = float.Parse(res.Tables[0].Rows[0]["fees"].ToString());
                 stu.Percent = float.Parse(res.Tables[0].Rows[0]["percent"].ToString());
                 MessageBox.Show(stu.ToString());*/
            }
            else
            {
                MessageBox.Show("Record with respect to id not exit");
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            Student s = new Student();
            s.Id = Convert.ToInt32(txtId.Value);
            s.Name = txtname.Text;
            s.Email = txtemail.Text;
            s.Phone = txtphone.Text;
            s.Fees = float.Parse(txtfees.Text.ToString());
            s.Percent = float.Parse(txtpercent.Text.ToString());
            string msg = ob.UpdateData(s);
            MessageBox.Show(msg);
            dataGridView1.DataSource = ob.getStudentDetails();
            dataGridView1.Visible = true;
        }
    }
}
