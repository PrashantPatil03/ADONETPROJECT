﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADONETPROJECT
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //details
        private void button1_Click(object sender, EventArgs e)
        {
            Details ob = new Details();
            ob.Show();
            this.Hide();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        //insert
        private void button2_Click(object sender, EventArgs e)
        {
            InsertData ob = new InsertData();
            ob.Show();
            this.Hide();
        }
        //search button
        private void button3_Click(object sender, EventArgs e)
        {
            SearchForm ob = new SearchForm();
            ob.Show();
            this.Hide();
        }
//db_details
        private void button6_Click(object sender, EventArgs e)
        {
            DbDetails ob = new DbDetails();
            ob.Show();
            this.Hide();
        }
//update
        private void button4_Click(object sender, EventArgs e)
        {
            UpdateData ob = new UpdateData();
            ob.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DeleteData ob = new DeleteData();
            ob.Show();
            this.Hide();
        }

        private void iNSERTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InsertData ob = new InsertData();
            ob.Show();
            this.Hide();
        }

        private void uPDATEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateData ob = new UpdateData();
            ob.Show();
            this.Hide();
        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thank you for Visiting");
            Application.Exit();
        }

        private void dELETEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteData ob = new DeleteData();
            ob.Show();
            this.Hide();
        }

        private void dETAILSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Details ob = new Details();
            ob.Show();
            this.Hide();
        }

        private void sEARCHToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchForm ob = new SearchForm();
            ob.Show();
            this.Hide();
        }

        private void mODIFYToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void sEARCHPERCENTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchPercent ob = new SearchPercent();
            ob.Show();
            this.Hide();
        }
    }
}
